export const environment = {
  apiUrl: 'https://apiseminariosdata.onrender.com',
  production: true
};
